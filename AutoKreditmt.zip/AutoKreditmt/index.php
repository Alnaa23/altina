<?php
/* ==========================================================
   AUTO KREDIT - Simulasi Angsuran Mobil
   Rumus: (Harga Mobil + Bunga 20% - DP) / (Tenor x 12 bulan)
   ========================================================== */

$harga  = '';
$dp     = '';
$tenor  = '';
$mobil  = '';
$hasil  = false;

$bunga      = 0;
$nominalDp  = 0;
$jumlahBulan = 0;
$angsuran   = 0;

/* Daftar mobil + harga + gambar */
$daftarMobil = [
    'Avanza'  => ['nama' => 'Toyota Avanza',     'harga' => 250000000, 'img' => 'https://images.unsplash.com/photo-1550355291-bbee04a92027?auto=format&fit=crop&w=600&q=80'],
    'Innova'  => ['nama' => 'Toyota Innova',     'harga' => 400000000, 'img' => 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=600&q=80'],
    'Brio'    => ['nama' => 'Honda Brio',        'harga' => 180000000, 'img' => 'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=600&q=80'],
    'HRV'     => ['nama' => 'Honda HR-V',        'harga' => 350000000, 'img' => 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=600&q=80'],
    'Xpander' => ['nama' => 'Mitsubishi Xpander','harga' => 300000000, 'img' => 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=600&q=80'],
    'Pajero'  => ['nama' => 'Mitsubishi Pajero', 'harga' => 600000000, 'img' => 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=600&q=80'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobil = $_POST['mobil'] ?? '';
    $harga = (float) ($_POST['harga_mobil'] ?? 0);
    $dp    = (int)   ($_POST['dp'] ?? 0);
    $tenor = (int)   ($_POST['tenor'] ?? 0);

    // Kalau pilih mobil dari daftar, pakai harga dari daftar
    if ($mobil !== '' && $mobil !== 'manual' && isset($daftarMobil[$mobil])) {
        $harga = $daftarMobil[$mobil]['harga'];
    }

    if ($harga > 0 && $dp > 0 && $tenor > 0) {
        $bunga       = $harga * 20 / 100;
        $nominalDp   = $harga * $dp / 100;
        $jumlahBulan = $tenor * 12;
        $angsuran    = ($harga + $bunga - $nominalDp) / $jumlahBulan;
        $hasil       = true;
    }
}

function rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoKredit</title>

    <link rel="icon" type="image/svg+xml"
          href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23f5f5f3' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M5 17h14M5 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm18 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4H3v-4z'/%3E%3C/svg%3E">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        :root{
            --bg:#080a0d; --surface:#101318; --line:rgba(255,255,255,.10);
            --line2:#252b33; --muted:#9299a5; --white:#f5f5f3;
        }
        html{scroll-behavior:smooth;scroll-padding-top:64px}
        body{background:var(--bg);color:var(--white);font:14px/1.5 'Segoe UI',Arial,sans-serif}

        /* NAVBAR */
        .auto-nav{height:64px;background:rgba(8,10,13,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
        .brand-mark{display:grid;place-items:center;width:32px;height:32px;border:1px solid rgba(255,255,255,.3);border-radius:8px}
        .brand-mark svg{width:18px;height:18px}
        .brand-name{font-size:17px;font-weight:700}
        .brand-name span{font-weight:400;color:#aab0b9}
        .nav-link{color:#aeb3bc!important;font-size:14.5px;padding:.5rem .8rem!important}
        .nav-link:hover,.nav-link.active{color:#fff!important}

        /* HERO */
        .hero-section{padding-top:64px;background:#050607}
        .hero-image{width:100%;height:calc(100vh - 64px);min-height:520px;object-fit:cover}
        .hero-overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(0,0,0,.78) 0%,rgba(0,0,0,.5) 45%,rgba(0,0,0,.15) 80%),linear-gradient(0deg,rgba(0,0,0,.55),transparent 55%)}
        .carousel-item{position:relative}
        .hero-caption{position:absolute;left:8%;top:50%;transform:translateY(-50%);max-width:560px;text-align:left;margin:0}
        .eyebrow{font-size:10.5px;font-weight:700;letter-spacing:.18em;color:#9ba2ad;margin:0}
        .hero-caption h1{font-size:clamp(26px,3.2vw,42px);line-height:1.1;font-weight:800;letter-spacing:-.03em;margin:10px 0 14px}
        .hero-caption h1 span{color:#b7bdc6}
        .hero-desc{max-width:480px;color:#d0d3d8;margin-bottom:20px}
        .hero-button{border-radius:8px;padding:9px 18px;font-size:13px;font-weight:700}
        .carousel-indicators{margin-bottom:18px}
        .carousel-control-prev,.carousel-control-next{width:7%}

        /* SECTION UMUM */
        .section-label{font-size:10.5px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:#9ba2ad;margin:0}
        .section-title{font-size:clamp(22px,2.4vw,30px);line-height:1.2;font-weight:800;letter-spacing:-.02em;margin:8px 0 14px}
        .section-text{max-width:560px;color:var(--muted);font-size:13.5px;line-height:1.7}

        /* TENTANG */
        .about-section{background:#0c0f13;border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:80px 0;min-height:calc(100vh - 64px);display:flex;align-items:center}
        .about-photo{width:100%;height:100%;min-height:380px;object-fit:cover;border-radius:20px;border:1px solid var(--line)}

        /* SECTION PILIH MOBIL */
        .mobil-section{background:var(--bg);padding:64px 0;border-top:1px solid var(--line)}
        .mobil-item{position:relative;cursor:pointer;margin:0;display:block}
        .mobil-item input{position:absolute;opacity:0;pointer-events:none}
        .mobil-card{border:1px solid var(--line2);border-radius:14px;background:var(--surface);overflow:hidden;transition:.2s;height:100%;display:flex;flex-direction:column}
        .mobil-card img{width:100%;height:150px;object-fit:cover;display:block}
        .mobil-card .mobil-info{padding:12px 14px;flex-grow:1;display:flex;flex-direction:column;justify-content:center}
        .mobil-card .mobil-nama{font-size:13.5px;font-weight:700;color:#e5e7eb}
        .mobil-card .mobil-harga{font-size:12.5px;color:#9097a1;margin-top:3px}
        .mobil-item input:checked+.mobil-card{border-color:#f1f1ef;box-shadow:0 0 0 1px #f1f1ef;transform:translateY(-2px)}
        .mobil-item:hover .mobil-card{border-color:#4b525c}

        /* KREDIT */
        .calculator-section{background:#0c0f13;padding:64px 0;border-top:1px solid var(--line)}
        .calculator-card,.info-card{border:1px solid var(--line);border-radius:16px;background:var(--surface);box-shadow:0 14px 40px rgba(0,0,0,.22);height:100%;display:flex;flex-direction:column;padding:22px}
        .info-card{background:linear-gradient(145deg,#151920,#0e1115)}
        .field-box{border:1px solid var(--line);border-radius:12px;padding:16px;background:#0d1015;margin-bottom:12px}
        .field-title{font-size:12.5px;font-weight:700;margin:0 0 10px}
        .form-control,.form-select,.input-group-text{background:#0b0e12!important;color:#f3f4f6!important;border-color:var(--line2)!important;font-size:13.5px;padding:9px 12px}
        .form-control:focus,.form-select:focus{border-color:#777f8c;box-shadow:0 0 0 .15rem rgba(255,255,255,.06)}
        .input-group-text{color:#9097a1!important}
        .info-bunga{display:flex;align-items:center;gap:10px;margin-top:12px;padding:10px 14px;font-size:12.5px;color:#c6cad1;background:#0b0e12;border:1px solid var(--line2);border-radius:9px}
        .icon-i{display:grid;place-items:center;width:20px;height:20px;border-radius:50%;background:#252b33;color:#d0d3d8;font-size:11px;font-weight:800;font-style:italic;font-family:Georgia,serif}
        .calculate-button{border-radius:10px;font-weight:700;padding:13px;font-size:13.5px;background:#3a3f47;border:none;color:#f5f5f3;margin-top:14px;width:100%}
        .calculate-button:hover{background:#4a505a;color:#fff}

        /* Toggle mode di form */
        .mode-switch{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}
        .mode-switch label{position:relative;cursor:pointer;margin:0}
        .mode-switch input{position:absolute;opacity:0;pointer-events:none}
        .mode-switch span{display:flex;align-items:center;justify-content:center;gap:6px;min-height:42px;border:1px solid var(--line2);border-radius:9px;background:#0b0e12;color:#aeb4bd;font-size:12.5px;font-weight:700;transition:.15s;user-select:none}
        .mode-switch input:checked+span{background:#f1f1ef;color:#080a0d;border-color:#f1f1ef}
        .mode-switch span:hover{border-color:#4b525c}
        .mode-switch svg{width:14px;height:14px}

        /* PILIHAN DP & TENOR */
        .pilihan-grid{display:grid;gap:7px}
        .dp-grid{grid-template-columns:repeat(6,1fr)}
        .tenor-grid{grid-template-columns:repeat(5,1fr)}
        .pilihan-item{position:relative;cursor:pointer;margin:0}
        .pilihan-item input{position:absolute;opacity:0;pointer-events:none}
        .pilihan-item span{display:flex;align-items:center;justify-content:center;min-height:38px;padding:6px 2px;border:1px solid var(--line2);border-radius:8px;background:#0b0e12;color:#aeb4bd;font-size:12px;font-weight:700;transition:.15s;user-select:none;white-space:nowrap}
        .pilihan-item input:checked+span{background:#f1f1ef;color:#080a0d;border-color:#f1f1ef}
        .pilihan-item:hover span{border-color:#4b525c}

        /* HASIL */
        .info-card h3{font-size:19px;font-weight:800;margin:0}
        .result-highlight{padding:18px 20px;margin-top:14px;border-radius:12px;background:#f1f1ef;color:#080a0d;text-align:center}
        .result-highlight p{margin:0;color:#64676c;font-size:12px}
        .result-highlight h3{font-size:24px;letter-spacing:-.03em;margin:6px 0 0;font-weight:800}
        .detail-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 0;border-top:1px solid var(--line)}
        .detail-row:first-child{border-top:0}
        .detail-row small{color:#707783;font-size:11.5px}
        .detail-row strong{font-size:13px;color:#eef0f2;text-align:right}
        .result-empty{padding:40px 10px;text-align:center;color:#707783;margin:auto 0}
        .result-empty h3{color:#c6cad1;font-size:16px}
        .result-empty p{font-size:13px;margin:0}

        /* KONTAK */
        .contact-section{background:#0c0f13;border-top:1px solid var(--line);padding:90px 0 80px;min-height:calc(100vh - 64px);display:flex;align-items:center}
        .contact-card{border:1px solid var(--line);border-radius:18px;background:var(--surface);padding:30px 24px;height:100%;transition:.25s;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center}
        .contact-card:hover{border-color:rgba(255,255,255,.28);transform:translateY(-4px);box-shadow:0 18px 40px rgba(0,0,0,.35)}
        .contact-icon{display:grid;place-items:center;width:54px;height:54px;border-radius:14px;background:#0b0e12;border:1px solid var(--line);margin-bottom:16px}
        .contact-icon svg{width:24px;height:24px}
        .contact-card h5{font-size:14px;font-weight:700;margin:0 0 8px}
        .contact-card p{color:#9299a5;font-size:13px;margin:0}
        .contact-card a{color:#d0d3d8;text-decoration:none}
        .contact-card a:hover{color:#fff}
        .social-box{margin-top:32px;padding:28px 24px;border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,#151920,#0e1115);text-align:center}
        .social-box h5{font-size:13px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#9ba2ad;margin:0 0 16px}
        .social-row{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}
        .social-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 16px;border:1px solid var(--line);border-radius:10px;background:#0b0e12;color:#d0d3d8;text-decoration:none;font-size:13px;font-weight:600}
        .social-btn:hover{background:#f1f1ef;color:#080a0d;border-color:#f1f1ef}
        .social-btn svg{width:16px;height:16px}

        /* FOOTER */
        .footer-section{padding:50px 0 18px;background:#050607;border-top:1px solid var(--line)}
        .footer-brand{display:inline-flex;align-items:center;gap:8px;color:#f5f5f3;text-decoration:none;font-size:19px;font-weight:800}
        .footer-brand .brand-mark{width:30px;height:30px}
        .footer-brand .brand-mark svg{width:16px;height:16px}
        .footer-brand span{font-weight:400;color:#aab0b9}
        .footer-text{max-width:380px;color:#707783;font-size:12.5px;line-height:1.7;margin-top:10px}
        .footer-section h5{font-size:12.5px;margin-bottom:12px}
        .footer-section a:not(.footer-brand){display:block;color:#7e8590;text-decoration:none;font-size:12.5px;margin:7px 0}
        .footer-section a:not(.footer-brand):hover{color:#fff}
        .footer-section p{color:#7e8590;font-size:12.5px;line-height:1.7}
        .footer-bottom{display:flex;justify-content:space-between;gap:16px;padding-top:18px;margin-top:32px;border-top:1px solid var(--line);color:#555c66;font-size:11px}

        @media(max-width:991.98px){
            .hero-image{height:480px}
            .about-section,.contact-section{min-height:auto;padding:60px 0}
            .about-photo{min-height:280px}
            .tenor-grid{grid-template-columns:repeat(3,1fr)}
            .dp-grid{grid-template-columns:repeat(3,1fr)}
        }
        @media(max-width:575.98px){
            .hero-image{height:440px}
            .hero-caption{left:8%;right:8%}
            .calculator-card,.info-card{padding:18px}
            .footer-bottom{flex-direction:column;gap:6px}
            .tenor-grid{grid-template-columns:repeat(2,1fr)}
        }
    </style>
</head>
<body>

<!-- ================= NAVBAR ================= -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top auto-nav">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#beranda">
            <span class="brand-mark">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M5 17h14M5 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm18 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                    <path d="M3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4H3v-4z"/>
                </svg>
            </span>
            <span class="brand-name">Auto<span>Kredit</span></span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuUtama">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuUtama">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link" href="#beranda">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#tentang">Tentang</a></li>
                <li class="nav-item"><a class="nav-link" href="#pilih-mobil">Pilih Mobil</a></li>
                <li class="nav-item"><a class="nav-link" href="#kredit">Kredit</a></li>
                <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
            </ul>
        </div>
    </div>
</nav>

<main>

<!-- ================= BERANDA ================= -->
<section id="beranda" class="hero-section">
    <div id="sliderMobil" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#sliderMobil" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#sliderMobil" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#sliderMobil" data-bs-slide-to="2"></button>
        </div>
        <div class="carousel-inner">

            <div class="carousel-item active">
                <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1800&q=80" class="hero-image" alt="Mobil">
                <div class="hero-overlay"></div>
                <div class="carousel-caption hero-caption">
                    <p class="eyebrow">SOLUSI PEMBIAYAAN MOBIL</p>
                    <h1>Rencanakan perjalananmu<br><span>dengan lebih pasti.</span></h1>
                    <p class="hero-desc">Hitung estimasi angsuran mobil berdasarkan harga, uang muka, dan tenor yang kamu pilih.</p>
                    <a href="#pilih-mobil" class="btn btn-light hero-button">Mulai Simulasi</a>
                </div>
            </div>

            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1800&q=80" class="hero-image" alt="Mobil">
                <div class="hero-overlay"></div>
                <div class="carousel-caption hero-caption">
                    <p class="eyebrow">SIMULASI YANG SEDERHANA</p>
                    <h1>Masukkan angka,<br><span>lihat hasilnya.</span></h1>
                    <p class="hero-desc">Semua perhitungan dilakukan otomatis berdasarkan ketentuan simulasi.</p>
                    <a href="#pilih-mobil" class="btn btn-light hero-button">Hitung Sekarang</a>
                </div>
            </div>

            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=1800&q=80" class="hero-image" alt="Mobil">
                <div class="hero-overlay"></div>
                <div class="carousel-caption hero-caption">
                    <p class="eyebrow">AUTO KREDIT</p>
                    <h1>Pilih tenor sesuai<br><span>rencana pembayaranmu.</span></h1>
                    <p class="hero-desc">Tersedia pilihan tenor 1 sampai 5 tahun dengan DP 10 sampai 60 persen.</p>
                    <a href="#pilih-mobil" class="btn btn-light hero-button">Lihat Simulasi</a>
                </div>
            </div>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#sliderMobil" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
        <button class="carousel-control-next" type="button" data-bs-target="#sliderMobil" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
    </div>
</section>

<!-- ================= TENTANG ================= -->
<section id="tentang" class="about-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <p class="section-label">Tentang Perusahaan</p>
                <h2 class="section-title">Membantu menghitung rencana kredit mobil dengan lebih mudah.</h2>
                <p class="section-text">AutoKredit adalah website simulasi pembiayaan mobil yang membantu pengguna memperkirakan nominal angsuran berdasarkan harga mobil, persentase DP, dan tenor yang dipilih.</p>
                <p class="section-text">Dengan tampilan sederhana dan proses perhitungan otomatis, pengguna dapat melihat rincian harga mobil, DP, tenor, bunga, hingga estimasi angsuran per bulan.</p>
                <p class="section-text">Kami percaya bahwa keputusan finansial sebaiknya dimulai dari perhitungan yang jelas. Karena itu AutoKredit hadir sebagai alat bantu yang ringan, tanpa perlu membuat akun, dan bisa diakses kapan saja secara gratis.</p>
                <a href="#pilih-mobil" class="btn btn-outline-light mt-2 px-3 py-2">Coba Simulasi</a>
            </div>
            <div class="col-lg-6">
                <img src="https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80" alt="Mobil" class="about-photo">
            </div>
        </div>
    </div>
</section>

<!-- ================= PILIH MOBIL ================= -->
<section id="pilih-mobil" class="mobil-section">
    <div class="container">

        <div class="text-center mb-4">
            <p class="section-label">Langkah 1</p>
            <h2 class="section-title mb-0">Pilih Mobil</h2>
            <p class="section-text mx-auto mt-2">Klik salah satu mobil di bawah — harga otomatis terisi di form perhitungan.</p>
        </div>

        <div class="row g-3">

            <?php foreach ($daftarMobil as $key => $m): ?>
                <div class="col-6 col-md-4">
                    <label class="mobil-item">
                        <input type="radio" name="mobil_pilih" value="<?= $key ?>"
                               <?= $mobil === $key ? 'checked' : '' ?>
                               onchange="pilihMobil('<?= $key ?>', <?= $m['harga'] ?>, '<?= htmlspecialchars($m['nama']) ?>')">
                        <div class="mobil-card">
                            <img src="<?= $m['img'] ?>" alt="<?= $m['nama'] ?>">
                            <div class="mobil-info">
                                <div class="mobil-nama"><?= $m['nama'] ?></div>
                                <div class="mobil-harga"><?= rupiah($m['harga']) ?></div>
                            </div>
                        </div>
                    </label>
                </div>
            <?php endforeach; ?>

        </div>

    </div>
</section>

<!-- ================= KREDIT ================= -->
<section id="kredit" class="calculator-section">
    <div class="container">

        <div class="text-center mb-4">
            <p class="section-label">Langkah 2</p>
            <h2 class="section-title mb-0">Hitung Kredit Mobil</h2>
        </div>

        <div class="row g-4 align-items-stretch">

            <!-- CARD INPUT -->
            <div class="col-lg-6 d-flex">
                <div class="calculator-card w-100">
                    <form method="POST" action="#kredit" class="d-flex flex-column h-100">

                        <input type="hidden" name="mobil" id="inputMobil" value="<?= htmlspecialchars($mobil) ?>">

                        <!-- TOGGLE MODE: PILIH MOBIL / MANUAL -->
                        <div class="field-box">
                            <p class="field-title">Pilih Mobil atau Input Manual</p>
                            <div class="mode-switch">
                                <label>
                                    <input type="radio" name="mode" value="pilih"
                                           <?= ($mobil !== '' && $mobil !== 'manual' && isset($daftarMobil[$mobil])) ? 'checked' : '' ?>
                                           onchange="setMode('pilih')">
                                    <span>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M5 17h14M5 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm18 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                                            <path d="M3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4H3v-4z"/>
                                        </svg>
                                        Dari Daftar
                                    </span>
                                </label>
                                <label>
                                    <input type="radio" name="mode" value="manual"
                                           <?= $mobil === 'manual' ? 'checked' : '' ?>
                                           onchange="setMode('manual')">
                                    <span>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>
                                        </svg>
                                        Input Manual
                                    </span>
                                </label>
                            </div>
                            <select class="form-select" id="mobilSelect" onchange="pilihDariSelect(this.value)"
                                    <?= ($mobil !== '' && $mobil !== 'manual' && isset($daftarMobil[$mobil])) ? '' : 'style="display:none"' ?>>
                                <option value="">Pilih mobil</option>
                                <?php foreach ($daftarMobil as $key => $m): ?>
                                    <option value="<?= $key ?>" <?= $mobil === $key ? 'selected' : '' ?>>
                                        <?= $m['nama'] ?> — <?= rupiah($m['harga']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="field-box">
                            <p class="field-title">Harga Mobil (Rp)</p>
                            <div class="input-group">
                                <input type="number" class="form-control" id="harga_mobil" name="harga_mobil" min="1" placeholder="Masukkan harga mobil" value="<?= htmlspecialchars($harga) ?>" required>
                                <span class="input-group-text">Rp</span>
                            </div>
                        </div>

                        <div class="field-box">
                            <p class="field-title">DP (Persen)</p>
                            <select class="form-select mb-2" id="dpSelect" onchange="pilihDp(this.value)">
                                <option value="">Pilih DP</option>
                                <?php foreach ([10,20,30,40,50,60] as $p): ?>
                                    <option value="<?= $p ?>" <?= $dp === $p ? 'selected' : '' ?>><?= $p ?>%</option>
                                <?php endforeach; ?>
                            </select>
                            <div class="pilihan-grid dp-grid">
                                <?php foreach ([10,20,30,40,50,60] as $p): ?>
                                    <label class="pilihan-item">
                                        <input type="radio" name="dp" value="<?= $p ?>" <?= $dp === $p ? 'checked' : '' ?> required onchange="document.getElementById('dpSelect').value='<?= $p ?>'">
                                        <span><?= $p ?>%</span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="field-box">
                            <p class="field-title">Tenor (Tahun)</p>
                            <select class="form-select mb-2" id="tenorSelect" onchange="pilihTenor(this.value)">
                                <option value="">Pilih Tenor</option>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <option value="<?= $i ?>" <?= $tenor === $i ? 'selected' : '' ?>><?= $i ?> Tahun</option>
                                <?php endfor; ?>
                            </select>
                            <div class="pilihan-grid tenor-grid">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <label class="pilihan-item">
                                        <input type="radio" name="tenor" value="<?= $i ?>" <?= $tenor === $i ? 'checked' : '' ?> required onchange="document.getElementById('tenorSelect').value='<?= $i ?>'">
                                        <span><?= $i ?> Tahun</span>
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <div class="info-bunga">
                            <span class="icon-i">i</span>
                            Bunga tetap 20% dari harga mobil
                        </div>

                        <button type="submit" class="btn calculate-button">Hitung Angsuran</button>

                    </form>
                </div>
            </div>

            <!-- CARD HASIL -->
            <div class="col-lg-6 d-flex">
                <div class="info-card w-100">

                    <div>
                        <p class="section-label mb-1">Hasil Perhitungan</p>
                        <h3>Ringkasan simulasi</h3>
                    </div>

                    <?php if ($hasil): ?>
                        <div class="result-highlight">
                            <p>Angsuran Per Bulan</p>
                            <h3><?= rupiah($angsuran) ?></h3>
                        </div>
                        <div class="mt-2 flex-grow-1">
                            <?php if ($mobil !== '' && $mobil !== 'manual' && isset($daftarMobil[$mobil])): ?>
                                <div class="detail-row"><small>Mobil</small><strong><?= $daftarMobil[$mobil]['nama'] ?></strong></div>
                            <?php else: ?>
                                <div class="detail-row"><small>Mobil</small><strong>Input Manual</strong></div>
                            <?php endif; ?>
                            <div class="detail-row"><small>Harga Mobil</small><strong><?= rupiah($harga) ?></strong></div>
                            <div class="detail-row"><small>DP (Persen)</small><strong><?= $dp ?>%</strong></div>
                            <div class="detail-row"><small>Nominal DP</small><strong><?= rupiah($nominalDp) ?></strong></div>
                            <div class="detail-row"><small>Bunga 20% dari harga mobil</small><strong><?= rupiah($bunga) ?></strong></div>
                            <div class="detail-row"><small>Total Harga + Bunga</small><strong><?= rupiah($harga + $bunga) ?></strong></div>
                            <div class="detail-row"><small>Jumlah Pinjaman (Total - DP)</small><strong><?= rupiah($harga + $bunga - $nominalDp) ?></strong></div>
                            <div class="detail-row"><small>Tenor (Tahun)</small><strong><?= $tenor ?> Tahun</strong></div>
                            <div class="detail-row"><small>Jumlah Bulan (Tenor x 12)</small><strong><?= $jumlahBulan ?> Bulan</strong></div>
                            <div class="detail-row"><small>Angsuran Per Bulan</small><strong><?= rupiah($angsuran) ?></strong></div>
                        </div>
                    <?php else: ?>
                        <div class="result-empty">
                            <h3>Belum Ada Perhitungan</h3>
                            <p>Pilih mobil di langkah 1, lalu isi DP & tenor di langkah 2, kemudian klik <b>Hitung Angsuran</b>.</p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- ================= KONTAK ================= -->
<section id="kontak" class="contact-section">
    <div class="container">

        <div class="text-center mb-5">
            <p class="section-label">Hubungi Kami</p>
            <h2 class="section-title mb-3">Kontak Perusahaan</h2>
            <p class="section-text mx-auto">Punya pertanyaan seputar simulasi kredit? Silakan hubungi kami melalui kontak di bawah ini — tim kami siap membantu Anda pada hari kerja.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="contact-card">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                        </svg>
                    </div>
                    <h5>Alamat</h5>
                    <p>Jl. Sudirman No. 10<br>Semarang, Jawa Tengah</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="contact-card">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>
                        </svg>
                    </div>
                    <h5>Email</h5>
                    <p><a href="mailto:info@autokredit.com">info@autokredit.com</a></p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="contact-card">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2z"/>
                        </svg>
                    </div>
                    <h5>Telepon</h5>
                    <p><a href="tel:+6281234567890">+62 812-3456-7890</a></p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="contact-card">
                    <div class="contact-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 11.5a8.4 8.4 0 0 1-12.3 7.4L3 21l2.2-5.6A8.5 8.5 0 1 1 21 11.5z"/>
                            <path d="M8.5 9.5c.5 2.5 3.5 5.5 6 6l1.2-1.6 2.3 1.2"/>
                        </svg>
                    </div>
                    <h5>WhatsApp</h5>
                    <p><a href="https://wa.me/6281234567890" target="_blank">+62 812-3456-7890</a></p>
                </div>
            </div>
        </div>

        <div class="social-box">
            <h5>Ikuti Kami</h5>
            <div class="social-row">
                <a href="#" class="social-btn">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 21v-7h2.3l.4-2.8h-2.7V9.4c0-.8.2-1.4 1.4-1.4h1.5V5.5c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8v2H8.2V14h2.3v7h3z"/></svg>
                    Facebook
                </a>
                <a href="#" class="social-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
                    Instagram
                </a>
                <a href="#" class="social-btn">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.5 3h3l-6.6 7.5L20.8 21h-6l-4.7-6.2L4.8 21h-3l7-8L3 3h6.2l4.2 5.6L16.5 3zm-1 16h1.6L8.6 4.7H6.9L15.5 19z"/></svg>
                    Twitter / X
                </a>
                <a href="https://wa.me/6281234567890" target="_blank" class="social-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-12.3 7.4L3 21l2.2-5.6A8.5 8.5 0 1 1 21 11.5z"/><path d="M8.5 9.5c.5 2.5 3.5 5.5 6 6l1.2-1.6 2.3 1.2"/></svg>
                    WhatsApp
                </a>
            </div>
        </div>

    </div>
</section>

</main>

<!-- ================= FOOTER ================= -->
<footer class="footer-section">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <a href="#beranda" class="footer-brand">
                    <span class="brand-mark">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M5 17h14M5 17a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm18 0a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                            <path d="M3 13l2-5a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 8l2 5v4H3v-4z"/>
                        </svg>
                    </span>
                    Auto<span>Kredit</span>
                </a>
                <p class="footer-text">Simulasi kredit mobil yang sederhana untuk membantu memperkirakan angsuran berdasarkan data yang dipilih.</p>
            </div>
            <div class="col-sm-6 col-lg-3">
                <h5>Menu</h5>
                <a href="#beranda">Beranda</a>
                <a href="#tentang">Tentang Perusahaan</a>
                <a href="#pilih-mobil">Pilih Mobil</a>
                <a href="#kredit">Kredit</a>
                <a href="#kontak">Kontak</a>
            </div>
            <div class="col-sm-6 col-lg-4">
                <h5>Kontak Perusahaan</h5>
                <p>Jl. Sudirman No. 10<br>Semarang, Jawa Tengah</p>
                <p>info@autokredit.com<br>+62 812-3456-7890</p>
            </div>
        </div>
        <div class="footer-bottom">
            <span>&copy; <?= date('Y') ?> AutoKredit. All rights reserved.</span>
            <span>Altina Aprilia Putri XII PPL 2</span>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function pilihDp(val){document.querySelectorAll('input[name="dp"]').forEach(el=>el.checked=(el.value===val))}
    function pilihTenor(val){document.querySelectorAll('input[name="tenor"]').forEach(el=>el.checked=(el.value===val))}

    // Klik card mobil di section atas → isi harga + hidden key, scroll ke form
    function pilihMobil(key, harga, nama){
        // Aktifkan mode "pilih"
        document.querySelector('input[name="mode"][value="pilih"]').checked = true;
        // Pilih dropdown juga
        document.getElementById('mobilSelect').value = key;
        document.getElementById('mobilSelect').style.display = '';
        // Isi harga & readonly
        document.getElementById('harga_mobil').value = harga;
        document.getElementById('harga_mobil').readOnly = true;
        // Hidden key
        document.getElementById('inputMobil').value = key;
        // Scroll ke form
        document.getElementById('kredit').scrollIntoView({behavior:'smooth'});
    }

    // Toggle mode di form (Dari Daftar / Manual)
    function setMode(mode){
        const select = document.getElementById('mobilSelect');
        const harga  = document.getElementById('harga_mobil');
        const hidden = document.getElementById('inputMobil');

        if (mode === 'pilih') {
            select.style.display = '';
            // Kalau belum ada mobil dipilih, harga kosong & readonly
            if (!select.value) {
                harga.value = '';
                harga.readOnly = true;
            } else {
                pilihDariSelect(select.value);
            }
        } else {
            // Manual
            select.style.display = 'none';
            select.value = '';
            harga.value = '';
            harga.readOnly = false;
            hidden.value = 'manual';
            harga.focus();
        }
    }

    // Pilih dari dropdown di form
    function pilihDariSelect(key){
        const harga = document.getElementById('harga_mobil');
        const hidden = document.getElementById('inputMobil');
        if (key && harga) {
            // Ambil harga dari data-attribute? Kita pakai map manual
            const map = <?= json_encode(array_map(fn($m) => $m['harga'], $daftarMobil)) ?>;
            if (map[key]) {
                harga.value = map[key];
                harga.readOnly = true;
                hidden.value = key;
            }
        }
    }

    // Saat halaman load: kalau mode "pilih" aktif tapi belum pilih mobil, readonly-kan input harga
    document.addEventListener('DOMContentLoaded', function(){
        const modePilih = document.querySelector('input[name="mode"][value="pilih"]');
        const harga = document.getElementById('harga_mobil');
        if (modePilih && modePilih.checked) {
            const sel = document.getElementById('mobilSelect');
            if (!sel.value) {
                harga.readOnly = true;
            }
        }
    });
</script>

</body>
</html>